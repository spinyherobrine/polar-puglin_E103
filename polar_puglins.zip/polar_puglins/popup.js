console.log("POPUP JS LOADED");

document.addEventListener("DOMContentLoaded", () => {

  const chatBox = document.getElementById("chat-box");
  const userInput = document.getElementById("user-input");
  const sendBtn = document.getElementById("send-btn");
  const summarizeBtn = document.getElementById("summarize-btn");

  // ---- Utility: append message to chat ----
  function addMessage(text, sender) {
    const div = document.createElement("div");
    div.classList.add("message", sender);
    div.textContent = text;
    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  addMessage("Hello, I am Web Narrator AI. Ask me about this page.", "bot");

  // ---- Question Answering ----
  sendBtn.addEventListener("click", async () => {

    const question = userInput.value.trim();
    if (!question) return;

    addMessage(question, "user");
    userInput.value = "";

    addMessage("Reading this page...", "bot");

    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });

    chrome.tabs.sendMessage(
      tab.id,
      { type: "GET_PAGE_ELEMENTS" },
      async (response) => {

        if (chrome.runtime.lastError || !response) {
          addMessage("Cannot read content on this page.", "bot");
          return;
        }

        addMessage("Asking AI…", "bot");

        try {
          const res = await fetch("http://127.0.0.1:8000/ask", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              question: question,
              elements: response.elements
            })
          });

          const data = await res.json();
          addMessage(data.answer, "bot");

        } catch (err) {
          console.error(err);
          addMessage("Backend not reachable.", "bot");
        }
      }
    );
  });

  // ---- Summarization ----
  summarizeBtn.addEventListener("click", async () => {

    addMessage("Summarizing page...", "bot");

    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });

    chrome.tabs.sendMessage(
      tab.id,
      { type: "GET_PAGE_ELEMENTS" },
      async (response) => {

        if (chrome.runtime.lastError || !response) {
          addMessage("Cannot read page text.", "bot");
          return;
        }

        try {
          const res = await fetch("http://127.0.0.1:8000/summarize", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              elements: response.elements
            })
          });

          const data = await res.json();
          addMessage(data.summary, "bot");

        } catch (err) {
          console.error(err);
          addMessage("Backend not reachable.", "bot");
        }
      }
    );
  });

});
