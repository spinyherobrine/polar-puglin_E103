from fastapi import FastAPI
from pydantic import BaseModel
from transformers import pipeline

app = FastAPI()

# Load FLAN-T5 model
qa_model = pipeline(
    "text2text-generation",
    model="google/flan-t5-base"
)
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
class SummaryRequest(BaseModel):
    elements: list

@app.post("/summarize")
def summarize_page(data: SummaryRequest):

    page_text = "\n".join([e["text"] for e in data.elements])

    # limit to avoid token overflow
    page_text = page_text[:3000]

    result = summarizer(page_text, max_length=180, min_length=40, do_sample=False)

    return {"summary": result[0]["summary_text"]}
class Element(BaseModel):
    element_id: int
    text: str

class Query(BaseModel):
    question: str
    elements: list[Element]


@app.post("/ask")
def ask_page_ai(query: Query):

    # join only first 120 elements to avoid overflow
    texts = [el.text for el in query.elements if el.text]

    if not texts:
        return {"answer": "This page has no readable text."}

    page_text = " ".join(texts)

    # hard truncate to protect FLAN-T5 (VERY IMPORTANT)
    page_text = page_text[:4000]

    prompt = f"""
You are a helpful assistant that answers questions only from the web page content below.

If the answer is not clearly present, reply exactly:
I cannot find this information on this page.

PAGE CONTENT:
{page_text}

QUESTION:
{query.question}
ANSWER:
"""

    output = qa_model(
        prompt,
        max_length=200,
        truncation=True,
        clean_up_tokenization_spaces=True
    )[0]["generated_text"]

    # safety cleanup for hallucination
    if len(output.strip()) == 0:
        output = "I cannot find this information on this page."

    return {"answer": output}
@app.post("/summarize")
def summarize_page(query: Query):

    texts = [el.text for el in query.elements if el.text]

    if not texts:
        return {"summary": "This page contains no readable text."}

    page_text = " ".join(texts)

    # avoid token overflow
    page_text = page_text[:5000]

    prompt = f"""
Summarize the following webpage content in 5-7 clear bullet points.

Do NOT add information not present in the text.

TEXT:
{page_text}

SUMMARY:
"""

    output = qa_model(
        prompt,
        max_length=250,
        truncation=True
    )[0]["generated_text"]

    return {"summary": output}

