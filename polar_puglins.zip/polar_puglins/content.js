console.log("Web Narrator AI content script loaded");

/**
 * Extract readable elements from the page
 */
function extractElements() {
  const elements = document.body.querySelectorAll(
    "p, h1, h2, h3, h4, h5, h6, span, li, a, div"
  );

  let results = [];
  let id = 0;

  for (let el of elements) {
    const text = el.innerText?.trim();
    if (!text) continue;

    results.push({
      element_id: id,
      text: text.replace(/\s+/g, " ").slice(0, 300) // truncate safely
    });

    el.setAttribute("data-webnarrator-id", id);
    id++;
  }

  // Safety limit for heavy pages
  if (results.length > 150) {
    results = results.slice(0, 150);
  }

  console.log("Extracted elements:", results);
  return results;
}

/**
 * Listen for messages from popup/background
 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // 📄 Extract page content
  if (msg.type === "GET_PAGE_ELEMENTS") {
    sendResponse({ elements: extractElements() });
    return true;
  }

  // ✨ Highlight + scroll
  if (msg.type === "HIGHLIGHT_ELEMENT") {
    const el = document.querySelector(
      `[data-webnarrator-id="${msg.element_id}"]`
    );

    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });

      el.style.backgroundColor = "yellow";
      el.style.outline = "3px solid orange";
    }

    sendResponse({ ok: true });
    return true;
  }

});